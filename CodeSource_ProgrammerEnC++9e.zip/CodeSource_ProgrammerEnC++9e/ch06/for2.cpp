#include <iostream>
using namespace std ;
int main ()
{  int i ;
   i = 1 ;
   while (i<=5)
      {  cout << "bonjour " ;
         cout << i << " fois\n" ;
         i++ ;
      }
}
