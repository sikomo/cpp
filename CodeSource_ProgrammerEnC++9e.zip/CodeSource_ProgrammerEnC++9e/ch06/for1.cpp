#include <iostream>
using namespace std ;
int main ()
{  int i ;
   for ( i=1 ; i<=5 ; i++ )
      {  cout << "bonjour " ;
         cout << i << " fois\n"  ;
      }
}
