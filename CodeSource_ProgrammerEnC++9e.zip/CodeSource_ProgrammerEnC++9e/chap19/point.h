       /* ------------ D�claration de la classe point ------------- */
class point
{              /* d�claration des membres priv�s */
    int x ;
    int y ;
              /* d�claration des membres publics */
 public :
    void initialise (int, int) ;
    void deplace (int, int) ;
    void affiche () const ;
} ;
