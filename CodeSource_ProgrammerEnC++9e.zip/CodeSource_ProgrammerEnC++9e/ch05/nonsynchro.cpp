#include <iostream>
using namespace std ;
int main()
{
   int n, p ;
   cout << "donnez une valeur pour n : " ;
   cin >> n ;
   cout << "merci pour " << n << "\n" ;
   cout << "donnez une valeur pour p : " ;
   cin >> p ;
   cout << "merci pour " << p << "\n" ;
} 