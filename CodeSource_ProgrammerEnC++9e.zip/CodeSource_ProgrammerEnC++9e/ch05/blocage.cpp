#include <iostream>
using namespace std ;
int main()
{  int n = 12 ;
   char c = 'a' ;
   cout << "donnez un entier et un caractere :\n" ;
   cin >> n >> c ;
   cout << "merci pour " << n << " et " << c << "\n" ;
   cout << "donnez un caractere : " ;
   cin >> c ;
   cout << "merci pour " << c ;
 }
